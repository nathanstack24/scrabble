# cs3110-midterm-project
Need to run the command: export OCAMLRUNPARAM="l=5555555555"
in bash before running any of the make commands
